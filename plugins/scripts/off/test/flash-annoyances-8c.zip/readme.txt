Flash's X-Chat scripts:      
        http://digdilem.org/code/xchat/xcchat.php
        irc-flash@digdilem.org     Flash_ at #3am irc.quakenet.org and #perl irc.oftn.net        
        Written on and for Windows's X-Chat versions 2.4.x, although should run fine on Linux too.
        
Short Description:

Removes undesired lines in Xchat. 
K, maybe I'm intolerant, but I think that a lot of junk added by certain scripts (mostly Mirc-based) get old real quick.
 Example, "(Netsplit Detector) Netsplit between *.net and *.split - Invincible  " I mean, after you see a huge list of 
 splits, you really want to be told by the one guy left in your channel that a netsplit just happened? How cool is that?
 I can't make people fix their annoying scripts, but I can stop seeing them - hence this.
 The join/part thing is especially useful for huge low-signal chans where any useful text gets lost amongst a million
 joins/parts/quits/nick-changes/away/backs etc. 
 
# Your new irc controls:
#
#   /show-joins  -   Toggles join messages
#   /show-parts  -   Toggles part messages
#   /show-nicks  -   Toggles whether nick-changes are shown
#   /show-quits  -   Toggles quit messages
#   /show-thanks -   Toggles "Thanks for the Ops!/Voice" really annoying msgs.
#   /show-aways  -   Toggles "is away" and "is back" messages
#   /show-modes  -   Toggles ops/voice modes
#   /show-misc   -   Toggle misc filtering - Stupid annoying stuff
#   /show-np     -   Toggles "Now playing" messages.
#
#   /annoy-help  -   Shows help on all the above.
#   /annoy-stats -   Shows how many lines have been cleaned.
       

Note that you can add your own strings by adding to the @annoyances list in the .pl - you'll need to reload
the script before they work, though. (/unloadall first!)

History:
========
v.08c - Initial release.

Future plans: 
=============
 - Maybe a per-channel override, but this is mucho work and I probably can't  be bothered as I don't see me 
   using it myself. 
 - A fuller logging ability is possible, perhaps just logging stuff that's removed from Xchat, or maybe 
   logging everything.
 - Maybe put all "eaten" messages into a seperate chan/window/logfile?
 
        
Installation:
=============

0a. WINDOWS: YOU MUST HAVE THE PERL PLUGIN ENABLED AND PERL INSTALLED!
0b. LINUX: YOU MUST HAVE PERL INSTALLED!


1. Edit the .pl in your favourite text editor and make any obvious changes. All user settings are at the top.

2.
Copy the .pl and any .txt files to your X-Chat's HOME directory. 
        (The user's dir, not where you installed xchat)
        Under Windows XP - this dir is: "C:\Documents and Settings\YOUR_USER_NAME\Application Data\X-Chat 2". 
         When you find the right one you'll see a bunch of .conf files. You can quick-find by opening Logfiles 
         dir from Xchats prefs menu/logging and ascend one level. Note "Application Data" is set to HIDDEN by 
         default so you may not find it unless you enable hidden files in Explorer. 
         Yeah, I know - MS sucks, news at eleven.
        
        Under linux, it's "~/.xchat/" by default. 
        
3.
Load script in Xchat. Either use "/load "full path"" or the nice little popup menu. By placing .pl files in xchat's 
user home folder, they are automatically loaded by Xchat on startup, so you could just restart Xchat and it should load.

On Success, you will notice "Loading Flashy's  Script" printed somewhere, and (unless you disabled them),
