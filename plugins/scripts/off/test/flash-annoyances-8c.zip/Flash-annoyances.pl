#!/usr/bin/perl
#
# Flashy's script. irc-flash@digdilem.org - poke Flash_ at irc.quakenet.org - #3am
# If used in your own work, please include my name in it somewhere, thanks.
# 
# Flash-Annoyances. Toggles various things that conspire to fill your textbox up
# with junk. X-Chat doesn't have enough control over this by default, sadly.
#
# Quakenet, whilst good, seems to contain a lot of people with annoying irc habits. 
# Hence this script...
#
# Upside: Easy toggles of show joins/parts/away/quits/nick-changes etc
# Downside: Global only - no per-channel configurability. 
# 
# Your new irc controls:
#
#   /show-joins  -   Toggles join messages
#   /show-parts  -   Toggles part messages
#   /show-nicks  -   Toggles whether nick-changes are shown
#   /show-quits  -   Toggles quit messages
#   /show-thanks -   Toggles "Thanks for the Ops!/Voice" really annoying msgs.
#   /show-aways  -   Toggles "is away" and "is back" messages
#   /show-modes  -   Toggles ops/voice modes
#   /show-misc   -   Toggle misc filtering - Stupid annoying stuff
#   /show-np     -   Toggle "Now Playing"
#
#   /annoy-help  -   Shows all the above.
#   /annoy-stats -   How many lines eaten... (Pvt, not pub)
#
#################################################################################
# User Configuration box below
#################################################################################
# Default Settings - 0 to ignore, 1 to remove. (Toggle in-client, but here's the default)
#
$annoy_joins = 1;
$annoy_parts = 1;
$annoy_nicks = 1;
$annoy_quits = 1;
$annoy_thanks = 1;
$annoy_aways = 1;
$annoy_modes = 1;
$annoy_misc = 1;
$annoy_np = 1;
#
$annoy_debug = 0;   # If this is set, it shows you what it killed. If not, just kills.
#
# Add strings to the following to remove any lines containing them (case insensitive)
# Note that $annoy_misc must be enabled for these to work. Do not use short ones
# or it'll eat a lot of lines you don't want it to... Use "string","string2" etc.
#
my @annoyances = ("(Netsplit Detector)");
#
#################################################################################
#End configuration, don't touch anything below
#################################################################################
$annoy_version="0.8c";
Xchat::register( "Flashy's Annoyances Script", $annoy_version, "/annoy-help", "" );

Xchat::print "Loading Flashy's Annoyances Script $annoy_version";

my $ann_joins=0,$ann_parts=0,$ann_nicks=0,$ann_quits=0,$ann_modes=0,$ann_misc=0;
my $ann_thanks=0,$ann_aways=0,$ann_np=0,$ann_tot=0;
 
IRC::add_command_handler("show-joins", "show_joins");           # Works
IRC::add_command_handler("show-parts", "show_parts");           # Works
IRC::add_command_handler("show-nicks", "show_nicks");           # Works
IRC::add_command_handler("show-quits", "show_quits");           # Works
IRC::add_command_handler("show-modes", "show_modes");           # Works
IRC::add_command_handler("annoy-help", "annoy_help");           # Works
# Thanks, misc and away/back need special handling
IRC::add_command_handler("show-misc", "show_misc");             # Works
IRC::add_command_handler("show-thanks", "show_thanks");         # Works
IRC::add_command_handler("show-aways", "show_aways");           # Works - " is away", " is back"
IRC::add_command_handler("show-np", "show_np");                 # Works
IRC::add_command_handler("annoy-stats", "annoy_stats");         # Works

Xchat::hook_print( "Raw Modes", "an_voice");  # show-modes
Xchat::hook_print( "Join", "an_join");        # show-joins
Xchat::hook_print( "Part", "an_part");        # show-parts
Xchat::hook_print( "Quit", "an_quit");        # show-quits
Xchat::hook_print( "Change Nick", "an_nicks");        # show-nicks
IRC::add_message_handler("PRIVMSG", "watch_annoyances");    # Everything else

sub an_voice { # show-modes, removes voice/ops
    if ($annoy_modes) {
        if ($annoy_debug) { Xchat::print"Eating Mode change"; }
        $ann_modes++;
        $ann_tot++;
        return Xchat::EAT_XCHAT; 
        }
    }
sub an_join { # show-joins
    if ($annoy_joins) {
        if ($annoy_debug) { Xchat::print"Eating Join"; }
        $ann_joins++;
        $ann_tot++;
        return Xchat::EAT_XCHAT; 
        }
    }
sub an_part { # show-parts
    if ($annoy_parts) {
        if ($annoy_debug) { Xchat::print"Eating Part"; }
        $ann_parts++;
        $ann_tot++;
        return Xchat::EAT_XCHAT; 
        }
    }

sub an_quit { # show-quits
    if ($annoy_quits) {
        if ($annoy_debug) { Xchat::print"Eating Quit"; }
        $ann_quits++;
        $ann_tot++;
        return Xchat::EAT_XCHAT; 
        }
    }
sub an_nicks { # show-nicks
    if ($annoy_nicks) {
        if ($annoy_debug) { Xchat::print"Eating Nick-Change"; }
        $ann_nicks++;
        $ann_tot++;
        return Xchat::EAT_XCHAT; 
        }
    }

sub watch_annoyances {  # Main routine
    my $eat_it = 0;
    foreach $line (@_) {
        $line =~ m/\:(.*?)\!(.*?)\sPRIVMSG\s(.*?)\s\:(.*)?/;

        $a_nick = $1;
        $a_send = $2;
        $a_chan = $3;
        $a_line = $4;

        $a_line =~ s/^\s+//; # Remove trailing whitespace
        $a_line =~ s/\s+$//;
        Xchat::strip_code( $a_line ); # remove color codes
        # Check for " is away" lines
        if ($annoy_aways) {
                if (($a_line =~ / is away/i) or ($a_line =~ / is back/i) or ($a_line =~ / Away: /i) or ($a_line =~ / is away: /i) or ($a_line =~ / Back from:/i) or ($a_line =~ /I was gone for /i) or ($a_line =~ / I left at:/i) or ($a_line =~ / ist away /i)) { 
                    if ($annoy_debug) { Xchat::print "Away/Back string eaten"; }
                    $eat_it++;
                    $ann_aways++;
                }        
            }
        # Check for various "thanks for the..."
        if ($annoy_thanks){
                if (($a_line =~ /Thanks for the ops/i) or ($a_line =~ /Thanks for the \+/i) or ($a_line =~ /Thanks for the @/i) or ($a_line =~ /Thanks for the voice/i)) {
                if ($annoy_debug) { Xchat::print "Thanks string eaten"; }
                $eat_it++;
                $ann_thanks++;
                }      
            }
        if ($annoy_misc) {
            foreach(@annoyances) {                
                if ($a_line =~ /$_/i) {
                if ($annoy_debug) { Xchat::print "Stupid annoyance killed"; }
                $eat_it++;
                $ann_misc++;
                }
            }
        if ($annoy_np) {
            if (($a_line =~ /mp3\(/i) or ($a_line =~ /Now Playing/i) or ($a_line =~ /np: /i)) {
                if ($annoy_debug) { Xchat::print "Ate Now Playing"; }
                $eat_it++;
                $ann_np++;
            }
        }
        }
    if ($eat_it)    { $ann_tot++; return Xchat::EAT_XCHAT; }
    }

return Xchat::EAT_NONE;
}

# Various toggles
sub show_joins {
    if ($annoy_joins) 
        { $annoy_joins = 0; 
        Xchat::print"Join messages shown"; }
        else 
        { $annoy_joins = 1; Xchat::print"Join messages hidden"; }
}
sub show_parts {
    if ($annoy_parts) 
        { $annoy_parts = 0; Xchat::print"Part messages shown"; }
        else 
        { $annoy_parts = 1; Xchat::print"Part messages hidden"; }
}
sub show_nicks {
    if ($annoy_nicks) 
        { $annoy_nicks = 0; Xchat::print"Nick-change messages shown"; }
        else 
        { $annoy_nicks = 1; Xchat::print"Nick-change messages hidden"; }
}
sub show_quits {
    if ($annoy_quits) 
        { $annoy_quits = 0; Xchat::print"Quit messages shown"; }
        else 
        { $annoy_quits = 1; Xchat::print"Quit messages hidden"; }
}
sub show_thanks {
    if ($annoy_thanks) 
        { $annoy_thanks = 0; Xchat::print"Thanks messages shown"; }
        else 
        { $annoy_thanks = 1; Xchat::print"Thanks messages hidden"; }
}
sub show_aways {
    if ($annoy_aways) 
        { $annoy_aways = 0; Xchat::print"Away messages shown"; }
        else 
        { $annoy_aways = 1; Xchat::print"Away messages hidden"; }
}
sub show_modes {
    if ($annoy_modes) 
        { $annoy_modes = 0; Xchat::print"Modechange messages shown"; }
        else 
        { $annoy_modes = 1; Xchat::print"Modechange messages hidden"; }
}
sub show_misc {
    if ($annoy_misc) 
        { $annoy_misc = 0; Xchat::print"Misc messages shown"; }
        else 
        { $annoy_misc = 1; Xchat::print"Misc messages hidden"; }
}
sub show_np {
    if ($annoy_np) 
        { $annoy_np = 0; Xchat::print"Now Playing messages shown"; }
        else 
        { $annoy_np = 1; Xchat::print"Now Playing messages hidden"; }
}
sub annoy_stats {
    Xchat::print"Annoyances statistics since script start:";
    Xchat::print"Joins:         $ann_joins";
    Xchat::print"Parts:         $ann_parts";
    Xchat::print"Quits:         $ann_nicks";
    Xchat::print"Misc:          $ann_misc";
    Xchat::print"Thanks:        $ann_thanks";
    Xchat::print"Away/Backs:    $ann_aways";
    Xchat::print"Now Playing:   $ann_np";
    Xchat::print"Nick-Changes:  $ann_nicks";
    Xchat::print"Mode-Changes:  $ann_modes";
    Xchat::print"Total:         $ann_tot lines hidden";
#    Xchat::print"
}
sub annoy_help {
    Xchat::print"Annoyances toggle list:";
    Xchat::print"/show-joins    Toggle Join messages";
    Xchat::print"/show-parts    Toggle Part messages";
    Xchat::print"/show-nicks    Toggle Nick-change messages";
    Xchat::print"/show-quits    Toggle Quit messages";
    Xchat::print"/show-thanks   Toggle thanks messages";
    Xchat::print"/show-aways    Toggle Away/Back messages";  
    Xchat::print"/show-modes    Toggles Mode messages";
    Xchat::print"/show-np       Toggles Now Playing messages";
    Xchat::print"/show-misc     Toggles misc filtering";        
}