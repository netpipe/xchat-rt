#!/usr/bin/perl

# Usage: /wiki <keyword>
# Author: epoch @ irc.p2pchat.net #linux

use WWW::Wikipedia;
use Lingua::EN::Summarize;

Xchat::register('Wikipedia Script','1.0');
Xchat::print"* Wikipedia Script Loaded...";
Xchat::hook_command('wiki', \&wiki);

sub wiki {
	my $target = $_[1][1];
	$target =~ s/^\s+//;
	$target =~ s/\s+$//;
	my $go = WWW::Wikipedia->new();
	if ($go) {
		my $gitrdun = $go->search($target);
		if ($gitrdun) {
			my $wiki = summarize( $gitrdun->text, maxlength => 800 );
			Xchat::command("echo $wiki\n");
		}
	}
	return Xchat::EAT_NONE;
}
