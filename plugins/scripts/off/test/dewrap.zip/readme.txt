DEwrap v1.2 README

This is a plugin for XChat for Windows.  It has been tested on v2.0.7.
This plugin will NOT work on any other OS or platform (Linux, OS X, etc).
This plugin REQUIRES the darkenginex.dll, read below to find out more.

For the latest version, please visit:

http://techrono.net  (check the download section)


Installation:

Download DarkEngine from http://www.darkengine.net

** Darkengine v2.5 or later **

Place the darkenginex.dll in your xchat directory, usually:

C:\Program Files\xchat



Put the dewrap.dll file in your xchat plugin dir, usually:

C:\Program Files\xchat\plugins


Restart XChat, or use the Window->Plugins & Scripts menu to load the
dewrap.dll manually.

**NOTE	If you do NOT want to have dewrap automatically load every time
	you start XChat, then place the dewrap.dll in another directory
	and load it manually with the Plugins & Scripts menu whenever
	you wish to use it.

Everything should work at this point.  Join a channel and type /deversion
You should get an output of the current version and URL of XChat, 
DEWrap and DarkEngine

Typing /help will give a list of available commands from xchat and from
the dewrap plugin.  Most people will just use the /sysinfo and possibly
the /bandtot and /hdtotal commands.


Here's a list of the commands

*New this version

*totalhdspacefree	Total combined available HD space
*totalhdspace		Total combined HD space
*hdtotal		Total combined HD space reported as (Free / Total)
*chadapter		Dialog to change currently selected network interface
*totaldown		Total amount of data downloaded on current interface
*totalup		Total amount of data uploaded on current interface
*batlife		Remaining battery life
*batcharge		Battery charge status
*batpower		Are we using the battery or online-AC?
 bandtot		Current downlink and uplink bandwidth usage
 sysinfo		New preformatted sysinfo
 mbm5			Current temps, fan speeds, and voltages
 sysinfo2		Origional preformatted sysinfo from darkengine (coloured text)
 mbmvolt		Current MBM5 voltages
 mbmfan			Current MBM5 fan speeds
 mbmtemp		Current MBM5 temperatures
 soundcard		Name of primary soundcard
 bandup			Current uplink bandwidth usage
 banddown		Current downlink bandwidth usage
 conn			Primary network connection with IN/OUT
 uptimerecord		Record uptime as reported by the OS
 uptimelong		Uptime in long format
 uptime			Uptime in short format
 hdspace		List of harddisks with FREE/TOTAL
 winamp			Preformatted Winamp info showing current track (coloured text)
 res			Primary monitor resolution as HxVxBPP
 totalvideocards	Total count of videocards
 secvideocard		Name and driver of secondary videocard
 videocard		Name and driver of primary videocard
 monitor		EDID name of primary monitor
 memload		Memory load as a % of total physical
 physicalused		Used physical memory
 physicalavail		Available physical memory
 physicaltot		Total physical memory
 virtualused		Used virtual memory
 virtualavail		Available virtual memory
 virtualtot		Total virtual memory
 username		Username of current user
 installdate		Installation date of the current OS
 os			Name and build of the current OS
 cpuinfo		Brand name of the CPU
 cpucache		Size of L1/L2/L3 CPU caches
 cpuspeed		Speed of CPU
 cpudetails		Stepping info of the CPU
 cpucount		Number of CPUs
 cpuarch		CPU Architecture (always x86)
 cpuload		CPU Load as a %
 deversion		Current version and URL of XChat, DEWrap, and DarkEngine



VERION HISTORY

3-05-04 1.2
	- Enabled battery functions
	- Added new functions for DarkEngine v2.5
		Total down/up data
		combined free/total hd space
		Change adapter menu

3-02-04	1.1
	- Enabled the Motherboard Monitor 5 functions
	- Created a custom /sysinfo that has no coloured output
	- Moved the coloured output /sysinfo to /sysinfo2
	- Added help text to describe what each command does
	  try /help <command>  eg /help sysinfo
	


2-10-04	1.0
	- Initial Release
	- Imported most DLL functions from darkenginex.dll
	- No detailed help yet, wait for next version ;-)


